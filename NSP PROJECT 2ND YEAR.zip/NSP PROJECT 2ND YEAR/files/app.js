const express = require("express");
const bodyparser = require("body-parser");
const app = express();
const mongoose = require("mongoose");
app.use(bodyparser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.get("/", function (req, res) {
  res.sendFile(__dirname + "/index.html");
});
mongoose.connect("mongodb+srv://collegeDB:9HP6KrLOoKpypnPM@nakshatracluster.r9py04x.mongodb.net/?retryWrites=true&w=majority");
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  message: String,
});

const User = mongoose.model("User", userSchema);

app.post("/", function (req, res) {
  const name = req.body.name;
  const message = req.body.message;
  const email = req.body.email;
  const user = new User({
    name: name,
    message: message,
    email: email,
  });
  user.save();
  res.redirect("/")
});

app.listen(3000, function () {
  console.log("Server is running on port 3000.");
});
